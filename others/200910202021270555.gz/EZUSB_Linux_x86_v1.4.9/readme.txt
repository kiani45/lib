Contents -

	driver_ezusb_v1.4.9 - Contains driver (version 1.4.9) for EZ100PU/EZMINI
			:
                           check_env - Environment Check Script  
                           install - Install Script
                           driver_install - Sub Program for Installation
                           readme.txt - Installation Guide (English)
                           creadme.txt - Installation Guide (Traditional Chinese)
                           drivers/ezusb.so - Reader Driver
                           drivers/Info.plist - PCSCLITE USB hotplug config file
	
	mifdtest - Contains a simple PC/SC Testing program for identifying if the driver 
		  is installed and active.		  			
